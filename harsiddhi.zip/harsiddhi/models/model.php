<?php
define("CONNECTION1",dirname(dirname(__FILE__)));
include CONNECTION1 .'/connection.php' ;
include CONNECTION1 . '../doa/doa.php';

class model
{
	public function insertData($tbl,$data)
	{
	//	$doaObj = new Doa();
	//	$connection = new connection();
		//$conn = $connection->connect();
	$conn= mysqli_connect("localhost","root","ubuntu","students");
	if($conn->connect_error)
	{
			echo "error";

	}
	


		
		$data['education'] = implode(" ", $data['education']) ;
		$strcolumn = implode(",",$columnData);
		array_pop($data);

	//$sql = "INSERT INTO $tbl (" . implode(', ', $columnData) . ") "
     //    . "VALUES ('" . implode("', '", $data) . "')";

         //print_r($sql);




		$sql = "INSERT INTO $tbl (name,email,pass,gender,education,city,image)
VALUES ('" . implode("', '", $data) . "')";


         $sqlquery = mysqli_query($conn,$sql);
         return $sqlquery;
         //print_r($sqlquery);
		
	}
	
	}
?>