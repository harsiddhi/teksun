
<?php
define("CONNECTION",dirname(dirname(__FILE__)));
include CONNECTION .'/connection.php' ;
class LoginModel
{
	public function Logindata($email,$pass)
	{
			$conn= mysqli_connect("localhost","root","ubuntu","students");
			if($conn->connect_error)
			{
			echo "error";

			}
			//print_r($conn);

			$sql = "SELECT ID FROM std where email='$email' and pass='$pass'";
			print_r($sql);
			$result = mysqli_query($conn,$sql);
			print_r($result);

			$row = mysqli_fetch_row($result);
			$count = mysqli_num_rows($result);
			//echo $count;
			//echo "llll";
			return $count;



	}

}
?>