
<?php 
class connection
	{
		function connect()
		{
			$conn= mysqli_connect("localhost","root","ubuntu","students");
			//print_r($conn);

			return $conn;
		}
	}
	

	?>