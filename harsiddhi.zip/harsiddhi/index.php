
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<br>
<br>
<div class="container" style="border:1px solid #cecece;">

<h1>Teksun Technology </h1>
		<form method="post" name="student" action="controller/login.php">

			
				
				  <div class="form-group">
					    <label for="name">Email:</label>
					<input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
					</div>

				 <div class="form-group">
					   <label for="name">Password:</label> 					<input type="password" class="form-control" id="pwd" placeholder="Enter password"name="pass">
					</div>


					<input type="hidden" name="action" value="login">
				
				
								 <div class="form-group">


					<input type="submit" class="btn btn-info" name="submit" value="submit">
										</div>

					<a href="view/insert.php">Registration</a>
					

				
				
			
		</form>
		</div>  <!-- container close -- >
</body>
</html>
