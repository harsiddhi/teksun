<!DOCTYPE html>

<html>
<head>
	<title></title>
</head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<div class="container" style="border:1px solid #cecece;">

	<form method="POST" name="registration" action="../controller/controller.php" enctype="multipart/form-data">
		<table border="1">
		<h2>Harsiddhi</h2> 
			
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" required></td>
			</tr>
			
			<tr>
				<td>Email</td>
				<td><input type="email" name="email" required></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="pass" required></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender" value="0" checked="">Male
				<input type="radio" name="gender" value="1">Female</td>
			</tr>

			<tr>
				<td>Education</td>
				<td><input type="checkbox" name="education[]" value="MCA" checked>MCA
				<input type="checkbox" name="education[]" value="BCA">BCA</td>

			</tr>

			<tr>
				<td>City</td>
							<td>

				<select name="city" required>
				<option name="Ahmedabd">Ahmedabd
				</option>
				<option name="Surat">Surat
				</option>
				</select>
							</td>

			</tr>


			<tr>
				<td>Image</td>
				<td><input type="text" name="images" required ></td>
			</tr>
			<tr>
				<!--<td>gender</td>
				<!--<td>
				<input type="radio" name="gender" value="0">male
				<input type="radio" name="gender" value="1">female</td> -->
			</tr>
							
							<input type="hidden" name="action" value="registration">

			
			<tr> 
				<td><input type="submit"></td>
			</tr>
			</table>
			</form>
			
			
			


			
</body>
</html>