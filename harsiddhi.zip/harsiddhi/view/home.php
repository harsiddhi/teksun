<?php
session_start();
define("MODELDATA",dirname(dirname(__FILE__))); ?>
<script type="text/javascript">

	var IDLE_TIMEOUT = 60; //seconds
var _idleSecondsCounter = 0;
document.onclick = function() {
    _idleSecondsCounter = 0;
};
document.onmousemove = function() {
    _idleSecondsCounter = 0;
};
document.onkeypress = function() {
    _idleSecondsCounter = 0;
};
window.setInterval(CheckIdleTime, 1000);

function CheckIdleTime() {
    _idleSecondsCounter++;
    var oPanel = document.getElementById("SecondsUntilExpire");
    if (oPanel)
        oPanel.innerHTML = (IDLE_TIMEOUT - _idleSecondsCounter) + "";
    if (_idleSecondsCounter >= IDLE_TIMEOUT) {
        alert("Time expired!");
        document.location.href = "logout.php";
    }
}
</script>
<?php

	//print_r($conn);


include MODELDATA .'/models/model.php' ;

if(isset($_SESSION['name']))
{ ?><p style="color:red"><?php 
	echo "hello" . " " .$_SESSION['name'];
	?>
	</p>
	
	<p>
	<a href="logout.php">LOGOUT</a>
	</p>
<?php
}

?>