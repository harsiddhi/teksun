<?php
define("MODELPATHM",dirname(dirname(__FILE__)));
include MODELPATHM .'/models/model.php';
class controller
{

	public function checkAction()
	{
		
		$action = $_REQUEST['action'];
		//echo $action;
		$tbl = 'std';
		if(strtolower($action))
		{
			switch ($action) {
				case 'registration':
					$data = $_POST;
					//print_r($data);
					$result= $this->actioninsert($tbl,$data);
					print_r($result);
					if($result)
					{
						header('Location:../index.php');
						exit();
;
					}
					else
					{
						header('Location:../view/insert.php');
						exit();

					}



					
					break;

					default:
					# code...
					break;
			}
		}

	}



	public function actioninsert($tbl,$data)
	{
			$modelObj = new model();
			$result = $modelObj->insertData($tbl,$data);
			return $result;

	}
	
	
} 
$controllerObj = new controller();
$controllerObj->checkAction();
?>