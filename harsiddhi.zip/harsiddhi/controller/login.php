<?php
session_start();
define("MODELPATH",dirname(dirname(__FILE__)));
include MODELPATH .'/models/loginmodel.php';
class login
{
	public function logindata()
	{
		$action = $_REQUEST['action'];
		if(strtolower($action) == 'login')
		{
			$email = $_REQUEST['email'];
			$pass = $_REQUEST['pass'];
			$modelObj = new LoginModel();
			$result = $modelObj->Logindata($email,$pass);
			//print_r($result);


			if($result)
			{
				$_SESSION['name'] = $email;

				//$_SESSION['name'] = $email;
				header('Location:../view/home.php');
				exit();
			}
			else
			{
				header('Location:../view/error.php');
				exit();

			}


			

					}
	}
}
$loginObj = new login();
$loginObj->logindata();
?>